

# Converting simpleFoam to rhoSimpleFoam

# Table of Contents

1. [boundary condition files](#bcfiles)

1. [kinematic vs static pressure](#pressure)

1. [transportProperties vs thermophysicalProperties](#trans)

1. [fvSchemes file settings](#fvschemes)

1. [fvSolution file settings](#fvsolution)

1. [rhoSimpleFoam low/high speed - fvSolutions](#lowhigh)

1. [rhoSimpleFoam optional limiters - fvOptions](#limiters)

<br>

#

## "0" directory files

#

<a id="bcfiles"></a>

### boundary condition files

<br>

(additional files for T & alphaT are required in rhoSimpleFoam)

simpleFoam:
- files required are **p, U, k, omega & nut**

rhoSimpleFoam:
- files required are **p, T, U, k, omega, nut & alphat**

#

<a id="pressure"></a>

### kinematic vs static pressure

<br>

simpleFoam:
- uses the kinematic pressure $p/\rho$
- p file dimensions [0 2 -2 0 0 0 0];

rhoSimpleFoam:
- uses the standard static pressure
- p file dimensions [1 -1 -2 0 0 0 0];

#

## "constant" directory files

#

### turbulenceProperties

<br>

simpleFoam and rhoSimpleFoam have the same **turbulenceProperties** file

![](./images/turbulenceProperties.png)

#

<a id="trans"></a>

### transportProperties vs thermophysicalproperties

<br>

simpleFoam: **transportProperties** file is required

![](./images/transportProperties.png)

rhoSimpleFoam: **thermophysicalProperties** file is required

![](./images/thermophysicalProperties.png)

#

## "system" directory files

#

<a id="fvschemes"></a>

### fvSchemes file settings

<br>

simpleFoam: **fvSchemes** file

![](./images/fvSchemes1.png)

rhoSimpleFoam: **fvSchemes** file

![](./images/fvSchemes2.png)

#

<a id="fvsolution"></a>


### fvSolution file settings

<br>

simpleFoam: **fvSolution** file

![](./images/fvSolution1.png)

rhoSimpleFoam: **fvSolution** file

![](./images/fvSolution2.png)

#

<a id="lowhigh"></a>

### rhoSimpleFoam low/high speed **fvSolution** file

<br>

In rhoSimpleFoam, the **transonic** setting and the **URF** settings can be changed for low/high speed flows. These are advisory settings and the user may find better settings for their specific application. In the images below left is low speed, right is high speed.

![](./images/fvSolution2_low.png)
![](./images/fvSolution2_high.png)

#

<a id="limiters"></a>

### rhoSimpleFoam optional limiters **fvOptions** file

<br>

rhoSimpleFoam **may** (for some applications) require additional limiters (compared to simpleFoam). As well as the pressure limiter which can be specified in the **fvSolution** file, there are also limiters for **Temperature** and **Velocity** which can be specified in the **fvOptions** file.

![](./images/fvOptions2.png)
